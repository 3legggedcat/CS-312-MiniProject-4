# CS312-Group-Project
Franz Mischke and James Grotberg

A personalized streaming platform that offers a seamless browsing experience, detailed content information, and user reviews would enhance accessibility and user interaction with visual entertainment.
