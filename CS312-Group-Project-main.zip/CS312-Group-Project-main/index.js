import './sass/main.scss';
import './js/get-refs';
import './js/fetch-home-page';
import './js/search';
import './js/modal';
